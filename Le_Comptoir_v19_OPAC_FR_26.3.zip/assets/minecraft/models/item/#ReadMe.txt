If you want to add your own item models, follow these steps.
Copy head_female1 and rename it to head_female51 and subsequent numbers.
Open the JSON file using Notepad, Notepad++, or VSC.

Edit the following text:
Change "head": "item/head_male1" to "head": "item/head_male51"
Change "particle": "item/head_male1" to "particle": "item/head_male51"
