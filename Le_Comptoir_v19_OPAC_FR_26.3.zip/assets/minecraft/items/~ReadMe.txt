If you want to add your own item models, follow these steps.
Open the armor_stand.json file using Notepad, Notepad++, or VSC.

Edit the following text:
Copy and change the text below

{
        "when": [
          "Female50",
		  "female50",
          "Female Sit50",
		  "Female sit50",
		  "female Sit50",
		  "female sit50",
          "Female Right50",
		  "Female right50",
		  "female Right50",
		  "female right50",
		  "Female Left50",
		  "Female left50",
		  "female Left50",
		  "female left50",
		  "Female Walk50",
		  "Female walk50",
		  "female Walk50",
		  "female walk50"
        ],
        "model": {
          "type": "minecraft:model",
          "model": "item/player_female50"
        }
       }, #Make sure to add a "," if you're adding more.
	   
#In the final step, copy the following text and place it at the end.

],
      "fallback": {
        "type": "minecraft:model",
        "model": "item/armor_stand"
      }
    }
}




#Finished example:
{
        "when": [
          "Female51",
		  "female51",
          "Female Sit51",
		  "Female sit51",
		  "female Sit51",
		  "female sit51",
          "Female Right51",
		  "Female right51",
		  "female Right51",
		  "female right51",
		  "Female Left51",
		  "Female left51",
		  "female Left51",
		  "female left51",
		  "Female Walk51",
		  "Female walk51",
		  "female Walk51",
		  "female walk51"
        ],
        "model": {
          "type": "minecraft:model",
          "model": "item/player_female51"
        }
       }
      ],
      "fallback": {
        "type": "minecraft:model",
        "model": "item/armor_stand"
      }
    }
}
